import dblib.Registration;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.*;

public class Client {
    public static void main(String[] args) throws SQLException {
        Scanner n = new Scanner(System.in);

        System.out.println("I, Edwin Ng Wong, certify that this project is my work only. I have not used " +
                "source code from third parties (except those that were discussed in-class)");

        Registration r = new Registration("ism6236", "ism6236bo");
        if(r.IsConnected())
            System.out.println("Connected");
        else
            System.out.println("Connection Failed");

        System.out.print("Please enter semester: ");
        String semester = n.nextLine();
        System.out.print("Please enter year: ");
        String year = n.nextLine();

        System.out.printf("%-14s%-14s%-14s%-14s%-14s%-14s%-14s%-15s%-14s%-14s\n", "CourseNo", "SectionNo", "FacultyNo", "Room",
                "Capacity", "Days", "Time", "TotalEnrolled", "Semester", "Year");
        ArrayList<String> l = r.List(year,semester);
        for(int i = 0; i < l.size(); i++)
            System.out.println(l.get(i));

        char option = '\0';
        System.out.println("---------------------------------------------------------------------------------");
        System.out.println("L. List Classes");
        System.out.println("R. Register");
        System.out.println("Q. Quit");

        do {
            System.out.println("---------------------------------------------------------------------------------");
            System.out.print("Enter an option(In upper case): ");
            option = n.next().charAt(0);
            System.out.println("---------------------------------------------------------------------------------");
            System.out.println("\n");

            switch (option) {
                case 'R':{
                    System.out.print("Enter Student ID: ");
                    int studentId = n.nextInt();
                    System.out.print("Enter Course Number: ");
                    String courseNo = n.next();
                    System.out.print("Enter Section Number: ");
                    String sectionNo = n.next();
                    System.out.println("Rows affected: " + r.Register(studentId, courseNo, sectionNo));
                    System.out.println("\n");
                    break;
                }
                case 'L':{
                    System.out.print("Enter Student ID: ");
                    String studentId = n.next();
                    System.out.print("Enter Semester: ");
                    String semester2 = n.next();
                    System.out.print("Enter Year: ");
                    String year2 = n.next();
                    System.out.println("\n");
                    System.out.printf("%-10s%-13s%-10s%-10s%-10s\n", "CourseNo", "SectionNo", "Room", "Days", "Time");
                    ArrayList<String> m = r.List1(studentId, semester2, year2);
                    for(int i = 0; i < m.size(); i++)
                        System.out.println(m.get(i));
                    break;
                }
                case 'Q':
                    System.out.println("Bye Bye!!");
                    break;
                default:
                    System.out.println("Invalid option, please try again");
                    break;
            }
        }while (option != 'Q');
    }
}
