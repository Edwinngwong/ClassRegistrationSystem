package dblib;

import java.sql.*;
import java.util.ArrayList;

public class Registration {
    static private String mservername;
    static private String mdbname;
    static private Connection mcn;

    static {
        mservername = "MSSQLSERVER";
        mdbname = "Registration";
    }

    public Registration(String uid, String pass) {

        setConnection(uid, pass);

    }

    public boolean IsConnected() {
        return (mcn != null ? true : false);
    }

    public void setConnection(String uid, String pass) {
        try {

            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            String connectionUrl = "jdbc:sqlserver://localhost\\" + mservername
                    + ";databaseName=" + mdbname + ";user=" + uid + ";password=" + pass + ";";

            mcn = DriverManager.getConnection(connectionUrl);
            if (mcn == null)
                System.out.println("Connection Failed");
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
            System.out.println("Error code:" + ex.getErrorCode());//ex.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public ArrayList<String> List(String year, String semester) {
        ArrayList<String> rval = new ArrayList<String>();

        try {
            Statement s = mcn.createStatement();
            ResultSet rs = s.executeQuery("Select * from Section where year = " + year +
                    " and semester = '" + semester + "' and TotalEnrolled < Capacity");
            while (rs.next()) {
                String courseNum = rs.getString(1);
                String sectionNum = rs.getString(2);
                String facultyNum = rs.getString(3);
                String room = rs.getString(4);
                int capacity = rs.getInt(5);
                String days = rs.getString(6);
                String time = rs.getString(7);
                int totalEnrolled = rs.getInt(8);
                String sSemester = rs.getString(9);
                int sYear = rs.getInt(10);
                String st = String.format("%-14s%-14s%-14s%-14s%-14d%-14s%-14s%-15d%-14s%-14d", courseNum, sectionNum, facultyNum, room,
                        capacity, days, time, totalEnrolled, sSemester, sYear);
                rval.add(st);
            }
            s.close();
        } catch (SQLException sqle) {
            sqle.printStackTrace();
        }
        return rval;
    }

    public static ArrayList<String> List1(String stuNo, String semester, String year) {
        ArrayList<String> rval = new ArrayList<String>();

        try {
            Statement s = mcn.createStatement();
            ResultSet rs = s.executeQuery("SELECT section.CourseNo, section.SectionNo, SECTION.Room, SECTION.Days, SECTION.Time " +
                    "FROM SECTION, ENROLLMENT " +
                    "WHERE enrollment.StuNo = " + stuNo +
                    " AND section.Semester = '" + semester +
                    "' AND section.Year = " + year +
                    " AND section.CourseNo = enrollment.CourseNo AND section.SectionNo = enrollment.SectionNo;");
            while (rs.next()) {
                String courseNo = rs.getString(1);
                String sectionNo = rs.getString(2);
                String room = rs.getString(3);
                String days = rs.getString(4);
                String time = rs.getString(5);
                String st = String.format("%-10s%-13s%-10s%-10s%-10s", courseNo, sectionNo, room, days, time);
                rval.add(st);
            }
            s.close();
        } catch (SQLException sqle) {
            sqle.printStackTrace();
        }
        return rval;
    }
    public static int Register(int stuNo, String courseNo, String sectionNo){
        int totalEnrolled = 0;
        int totalCapacity = 0;
        try{
            PreparedStatement s = mcn.prepareStatement("SELECT TotalEnrolled FROM Section WHERE CourseNo = ? AND SectionNo = ?");
            s.setString(1,courseNo);
            s.setString(2,sectionNo);
            ResultSet rs = s.executeQuery();
            while (rs.next()){
                totalEnrolled = rs.getInt(1);
            }
            s.close();
        } catch (SQLException sqle){
            sqle.printStackTrace();
        }
        try{
            PreparedStatement s = mcn.prepareStatement("SELECT Capacity FROM Section WHERE CourseNo = ? AND SectionNo = ?");
            s.setString(1,courseNo);
            s.setString(2,sectionNo);
            ResultSet rs = s.executeQuery();
            while (rs.next()){
                totalCapacity = rs.getInt(1);
            }
            s.close();
        } catch (SQLException sqle){
            sqle.printStackTrace();
        }

        if (totalEnrolled < totalCapacity){
            int result = 0;
            try {
                String sql = "INSERT INTO ENROLLMENT (StuNo, CourseNo, SectionNo) VALUES (" + stuNo + ", '" + courseNo + "', '" + sectionNo + "')" +
                        " UPDATE SECTION SET TotalEnrolled = TotalEnrolled + 1 WHERE CourseNo = '" + courseNo + "' AND SectionNo = '" + sectionNo + "'";
                Statement s = mcn.createStatement();
                result = s.executeUpdate(sql);
            } catch (SQLException sqle){
                sqle.printStackTrace();
            }
            return result;
        }
        else{
            return -1;
        }
    }
    public static void main(String[] args){
    Registration r = new Registration("ism6236", "ism6236");
        if(r.IsConnected())
                System.out.println("Connected");
        else
                System.out.println("Connection Failed");
    }
}
